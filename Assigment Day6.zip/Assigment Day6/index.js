var songs=[

    {
        id:1,
        imageSrc:"./thumbnails/bad_liar.jpg",
        audioSrc:"./audio/Imagine_Dragons_-_Bad_Liar_(getmp3.pro).mp3",
        title:"Bad Liar - Imagine Dragons"
    },

    {
        id:2,
        imageSrc:"./thumbnails/beete_lamhe.jpg",
        audioSrc:"./audio/Beete_Lamhe_The_Train_1080p_Ful_(getmp3.pro).mp3",
        title:"Beete Lamhe - KK"
    },

    {
        id:3,
        imageSrc:"./thumbnails/believer.jpg",
        audioSrc:"./audio/Imagine_Dragons_-_Believer_(getmp3.pro).mp3",
        title:"Believer - Imagine Dragons"
    },

    {
        id:4,
        imageSrc:"./thumbnails/bhar_do_jholi.jpg",
        audioSrc:"./audio/Lyrical_Bhar_Do_Jholi_Meri_Ad_(getmp3.pro).mp3",
        title:"Bhar Do Jholi - Adnan Sami"
    },

    {
        id:5,
        imageSrc:"./thumbnails/blank_space.jpg",
        audioSrc:"./audio/Taylor_Swift_-_Blank_Space_(getmp3.pro).mp3",
        title:"Blank Space - Taylor Swift"
    },

    {
        id:6,
        imageSrc:"./thumbnails/finally_foun.jpg",
        audioSrc:"./audio/Enrique_Iglesias_-_Finally_Found_Yo_(getmp3.pro).mp3",
        title:"Finally Found You - Enrique Iglesias"
    },

    {
        id:7,
        imageSrc:"./thumbnails/dusk_till_dawn.jpg",
        audioSrc:"./audio/ZAYN_-_Dusk_Till_Dawn_Official_Vid_(getmp3.pro) (1).mp3",
        title:"Dusk Till Dawn - Zain Malik"
    },

    {
        id:8,
        imageSrc:"./thumbnails/hero.jpg",
        audioSrc:"./audio/Enrique_Iglesias_-_Hero_Official_M_(getmp3.pro).mp3",
        title:"Hero - Enrique Iglesias"
    },

    {
        id:9,
        imageSrc:"./thumbnails/kun_faya_kun.jpg",
        audioSrc:"./audio/Kun_Faya_Kun_Full_Video_Song_Rockst_(getmp3.pro).mp3",
        title:"Kun Faya Kun - Mohit Chauhan  / AR Rahman"
    },

    {
        id:10,
        imageSrc:"./thumbnails/namo_namo.webp",
        audioSrc:"./audio/Namo_Namo_-_Lyrical_Kedarnath_S_(getmp3.pro).mp3",
        title:"Namo Namo - Amit Trivedi"
    },

    {
        id:11,
        imageSrc:"./thumbnails/tum_se_hi.jpg",
        audioSrc:"./audio/Tum_Se_Hi_Lyrcial_Jab_We_Met_Ka_(getmp3.pro).mp3",
        title:"Tum Se Hi - Mohit Chauhan"
    },


]

function generateAudioCards()
{

    let htmlString="";

    songs.forEach(function(song,index){

        let songHTML=`

                <div class="audio">
                <div class="audio_img">
                    <img src="${song.imageSrc}">
                </div>
                <div class="audio_detail">
                    <h1 class="audio_title">${song.title}</h1>
                    <button class="btn" onclick="playAudio(${song.id})">▶</button>
                </div>
                </div>

        `;

        htmlString+=songHTML;

    })

    document.getElementById("audios").innerHTML=htmlString;


}

generateAudioCards();


function playAudio(songid)
{
    var song=songs.find(function(song,index){
        return song.id===songid
    });

    document.getElementById("thumbnail").src=song.imageSrc;
    document.getElementById("audio_player").src=song.audioSrc;
    document.getElementById("audio_player_title").innerText = song.title;
    document.getElementById("audio_player").play();

    
}

